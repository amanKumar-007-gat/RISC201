@ =====================================================================
@ hazard_raw.s — read-after-write (RAW) hazards on ALU results
@
@ Every consumer reads its producer's register in the immediately
@ following instruction — the worst possible distance of 1.
@
@   4-stage: the producer's result is forwarded into the consumer's
@            fused ID/OF read — same-cycle EX bypass for distance 1,
@            EX/WB register bypass for distance 2.  0 stalls.
@   6-stage: same idea one stage later — EX same-cycle bypass into
@            OF for distance 1, EX/MA and MA/WB bypasses beyond.
@            0 stalls (no interlock needed for ALU producers).
@
@ How to see it: the final stats line prints `bypasses=` — every
@ add/sub/mul below hits the forwarding network.  `redirects=0`,
@ `flushed=0`: only data forwarding is at work here.
@
@ Result: r1=5  r2=10  r3=15  r4=25  r5=20  r6=200
@ =====================================================================

mov r1, 5          @ producer
add r2, r1, r1     @ RAW(r1), distance 1
add r3, r2, r1     @ RAW(r2) distance 1 + RAW(r1) distance 2
add r4, r3, r2     @ RAW chain continues
sub r5, r4, r1     @ 25 - 5 = 20
mul r6, r5, r2     @ 20 * 10 = 200 (Booth)
.end:
