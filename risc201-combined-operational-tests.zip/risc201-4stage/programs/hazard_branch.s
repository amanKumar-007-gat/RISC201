@ =====================================================================
@ hazard_branch.s — control hazards and the cmp->branch flag hazard
@
@ Part 1  cmp r1,7 then beq .equal back-to-back:
@         SET_FLAGS commits the flags in EX and COND_BRANCH reads
@         them in EX of the NEXT instruction — 0 stalls on both
@         CPUs.  The branch is TAKEN, so the two (4-stage) / three
@         (6-stage) younger in-flight packets are squashed: this is
@         the taken-branch penalty (redirects=... flushed=...).
@ Part 2  cmp r1,99 / bgt .never is NOT taken: fall-through, 0
@         bubbles — mispredict-free.
@ Part 3  a 3-iteration countdown loop: every taken back-edge costs
@         the squash penalty again (visible in --trace as bubbles).
@
@ Result: r2 = 14, r3 = 21 (7+7+7), r4 = 0
@ =====================================================================

mov r1, 7
cmp r1, 7          @ flags written by SET_FLAGS in EX ...
beq .equal         @ ... read by COND_BRANCH in EX: no stall; TAKEN
nop                @ squashed — never retires
nop                @ squashed
.equal:
cmp r1, 99
bgt .never         @ NOT taken: 7 > 99 is false -> 0 bubbles
add r2, r1, r1     @ executes: r2 = 14
.never:
mov r3, 0
mov r4, 3
.loop:
add r3, r3, r1     @ r3 += 7
sub r4, r4, 1
cmp r4, 0          @ flags for the loop guard
bgt .loop          @ taken twice (r4=2,1), not taken when r4=0
.end:
