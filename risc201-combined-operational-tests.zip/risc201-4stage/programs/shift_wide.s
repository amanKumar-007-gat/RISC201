@ =====================================================================
@ shift_wide.s — shift amounts larger than 32 bits (LSL + LSR + ASR)
@
@ The Risc201 barrel shifter is a 32-bit shifter: the ALU dispatch
@ feeds it only the LOW 5 BITS of the shift amount
@ (alu.hpp: shl32/shr32/sra32 mask with & 0x1F, i.e. amount mod 32).
@ A shift by 32 or more therefore WRAPS AROUND instead of producing
@ zero or trapping — no exception is raised, no flag is changed.
@
@   amount 33 -> 1     amount 32 -> 0 (value unchanged)
@   amount 64 -> 0     amount 35 -> 3     amount 100 -> 4
@
@ The cmp/beq pairs prove the wrap-around: e.g. `lsl r2, r1, 33`
@ must equal a true 1-bit shift `lsl r8, r1, 1`.
@
@ Result:
@   LSL: r2=2 (33->1)  r3=1 (32->0)  r4=1 (64->0)  r5=8 (35->3)
@        r6=100        r7=16 (100->4) r8=2 (control 1-bit)
@   LSR: r9=0x80000000  r10=0x40000000 (33->1)  r11=0x80000000 (32->0)
@   ASR: r12=0x80000000 r13=0xC0000000 (33->1, sign fill)
@        r0=0x80000000 (32->0, unchanged)
@   all three mismatch markers stay 0
@ =====================================================================

mov r1, 1          @ base value for the LSL tests

lsl r2, r1, 33     @ 33 & 31 = 1   -> r2 = 2
lsl r3, r1, 32     @ 32 & 31 = 0   -> r3 = 1 (unchanged)
lsl r4, r1, 64     @ 64 & 31 = 0   -> r4 = 1
lsl r5, r1, 35     @ 35 & 31 = 3   -> r5 = 8
mov r6, 100        @ register-form amount ...
lsl r7, r1, r6     @ ... 100 & 31 = 4 -> r7 = 16
lsl r8, r1, 1      @ control: true single-bit shift -> 2
cmp r2, r8         @ 33 (mod 32) == 1 ?
beq .lsl_ok        @ taken: wrap-around proven
mov r9, 1          @ mismatch marker (never executed)
.lsl_ok:

movh r9, 0x8000    @ r9 = 0x80000000 (movh = upper-half immediate)

lsr r10, r9, 33    @ 33 & 31 = 1   -> r10 = 0x40000000
lsr r11, r9, 32    @ 32 & 31 = 0   -> r11 = 0x80000000 (unchanged)
cmp r11, r9        @ shifting "by 32" left the value alone?
beq .lsr_ok        @ taken
mov r12, 1         @ mismatch marker (never executed)
.lsr_ok:

movh r12, 0x8000   @ r12 = 0x80000000 (most-negative value)

asr r13, r12, 33   @ 33 & 31 = 1   -> r13 = 0xC0000000 (sign-filled)
asr r0, r12, 32    @ 32 & 31 = 0   -> r0 = 0x80000000 (unchanged)
cmp r0, r12
beq .asr_ok        @ taken
mov r0, 1          @ mismatch marker (never executed)
.asr_ok:

.end:
