@ =====================================================================
@ data_words.s — data embedded in the instruction stream
@                (user test case 3)
@
@ The two-pass assembler allocates addresses for labels AND for
@ .word data, so a data block can sit between instructions.
@ `mov r3, arr` turns the symbol `arr` into an immediate (its
@ address).  The unconditional branch jumps OVER the data block —
@ data words are never fetched as instructions — and execution
@ ends cleanly when IF fetches the first zero word past the image.
@
@ Memory layout:
@   0x00 mov r3, arr      0x08..0x20  arr: 1,2,3,4,5,6,-44
@   0x04 b   .end         0x24        .end  (end of image)
@
@ -44 is stored little-endian as 0xFFFFFFD4 (two's complement).
@ Expected result: r3 = 0x00000008 (= &arr), clean halt at 0x24.
@ =====================================================================

        mov r3, arr        @ r3 = address of arr (symbol -> immediate)
.done:
        b .end             @ skip over the data words
arr:
        .word 1,2,3,4,5,6,-44
.end:
