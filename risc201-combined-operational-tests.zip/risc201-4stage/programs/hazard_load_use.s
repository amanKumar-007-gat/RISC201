@ =====================================================================
@ hazard_load_use.s — load-use hazard: ld feeding a consumer
@
@ The load result exists only after the memory access:
@   4-stage: memory is fused into EX, and the consumer's operand
@            read is fused into ID — by the time the consumer reads
@            registers, EX has just produced the load data, so the
@            same-cycle bypass covers even distance 1.  0 stalls.
@   6-stage: the load reads memory in MA, one cycle AFTER EX, while
@            a dependent instruction in OF would read registers one
@            cycle too early.  The interlock (detect_of_stall) holds
@            the consumer in ID/OF for exactly 1 bubble, then the MA
@            same-cycle bypass delivers the fresh data.  At distance
@            2 the load data is already in MA/WB -> no stall.
@
@ Pair 1 (distance 1): ld r2 ... / add r3,r2,r2     <- the hazard
@ Pair 2 (distance 2): ld r4 / mov r13,r13 / add r5 <- bypassed clean
@ (mov r13,r13 is an architectural no-op used as spacing; unlike the
@  `nop` mnemonic its ROM routine contains real µops, so it retires
@  normally on both CPUs and keeps the retired counts comparable.)
@
@ How to see it: run with --trace.  On the 6-stage CPU the first
@ `add` is held one cycle in the ID column (a bubble appears in
@ OF/EX); on the 4-stage CPU no bubble ever appears.
@
@ Result: r1=&arr  r2=21  r3=42  r4=34  r5=55  (r13 unchanged)
@ =====================================================================

mov r1, arr        @ r1 = &arr
ld  r2, 0[r1]      @ load arr[0] ...
add r3, r2, r2     @ ... consumed by the VERY NEXT instruction (hazard)
ld  r4, 4[r1]      @ load arr[1]
mov r13, r13       @ spacing: next consumer sits at distance 2
add r5, r4, r2     @ distance 2: no stall even on the 6-stage CPU
b .end

arr: .word 21, 34
.end:
