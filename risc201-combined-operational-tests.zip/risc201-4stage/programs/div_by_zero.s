@ =====================================================================
@ div_by_zero.s — divide-by-zero exception demo (user test case 1)
@
@ The Goldschmidt divider raises its exception bit when the divisor
@ is zero.  The ALU_OP µop detects it in EX, squashes every younger
@ in-flight packet (precise exception) and the CPU halts with
@ ExKind::DivByZero.  r1 keeps its old value (10): the faulting div
@ never reaches WB, so no architectural state is corrupted.
@
@ Expected run output (both CPUs):
@   runtime exception: DivisionByZero at pc=0x8
@        — Division by zero in EX (Goldschmidt)
@   r1 = 0x0000000a  (10, unchanged)   r2 = 0x00000000
@ =====================================================================

mov r1, 10          @ numerator
mov r2, 0           @ divisor = 0  ->  exception
div r1, r1, r2      @ EX: alu_execute(OP_DIV) sets exception=1

b .end              @ never executed: squashed with the younger packets

.end:
