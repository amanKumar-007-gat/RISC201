@ =====================================================================
@ stack_overflow_loop.s — minimal stack-overflow trigger (user test 2)
@
@ Full-descending stack: SP starts at STACK_BASE = 0xFFFC and the
@ floor is STACK_LIMIT = 0x8000.  Each pass of the loop subtracts 4
@ from sp; the WB-stage REG_WRITE µaction checks every destination
@ that is sp and raises StackOverflow as soon as SP < 0x8000.
@
@ Iteration math: (0xFFFC - 0x7FFC) / 4 = 8192 iterations; on the
@ 8192nd `sub` SP becomes 0x7FFC and the exception fires.
@
@ Expected run output (both CPUs):
@   runtime exception: StackOverflow at pc=0x0
@        — SP=0x00007ffc crossed stack floor (LIMIT=0x00008000)
@   sp = 0x00007ffc
@ =====================================================================

.loop:
    sub  r14,r14,4      @ sp -= 4  (checked in WB: REG_WRITE of sp)
    b .loop             @ taken back-edge -> redirect + squash every time
