@ =====================================================================
@ hazard_call_ret.s — procedure-link (ra) hazards: call / ret
@
@ call commits ra = PC+4 with LINK_RA in EX — EARLY, the same cycle
@ the call is in EX — so ra is already in the register file before
@ any younger instruction can read it (no ra hazard by construction).
@ ret reads ra in EX (PC_LOAD_TARGET) and redirects; on the 6-stage
@ CPU a dedicated EX-stage bypass (fwd_ex_ra) also covers ra results
@ still travelling through MA/WB.  The call's redirect squashes the
@ younger fetch/decode packets: 2 bubbles (4-stage) / 3 (6-stage).
@
@ The function is called twice back-to-back to show the link
@ register surviving two call/ret round trips.
@
@ Result: r1 = 12 (3 doubled twice), r2 = 18 (6 + 12)
@ =====================================================================

mov r1, 3
mov r2, 0
call .double       @ ra = &add r2 (next instruction); jumps .double
add r2, r1, r2     @ return lands here: r2 = 6 + 0 = 6
call .double       @ second round trip: r1 = 6 -> 12
add r2, r1, r2     @ r2 = 12 + 6 = 18
b .end
.double:
add r1, r1, r1     @ RAW on r1 right after the redirect (bypassed)
ret                @ PC = ra
.end:
